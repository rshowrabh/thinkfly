<?php

namespace Joaopaulolndev\FilamentGeneralSettings\Testing;

use Livewire\Features\SupportTesting\Testable;

/**
 * @mixin Testable
 */
class TestsFilamentGeneralSettings
{
    //
}
