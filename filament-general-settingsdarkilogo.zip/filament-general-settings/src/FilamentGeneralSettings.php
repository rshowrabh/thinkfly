<?php

namespace Joaopaulolndev\FilamentGeneralSettings;

class FilamentGeneralSettings {}
